Needs 2 Xbox 360 Controllers, best played in 1280 x 800.

A/B/X/Y to Chop.

Keyboard controls:

Player 1: 
Chop: X, Z, S, A
Combo: X + Z + A, X + A
Start Game: X
Back: Z
Return to main menu: Escape

Player 2:
Chop: M, N, K, J
Combo: M + N + J, M + J

XBox 360 controls:

Player 1: 
Chop: X, Z, S, A
Combo: X + Z + A, X + A
Start Game: A
Back: X
Return to main menu: Escape

Player 2:
Chop: M, N, K, J
Combo: M + N + J, M + J